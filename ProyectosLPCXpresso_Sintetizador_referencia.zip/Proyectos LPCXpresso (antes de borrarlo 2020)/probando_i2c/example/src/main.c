/*
 * @brief FreeRTOS Blinky example
 *
 * @note
 * Copyright(C) NXP Semiconductors, 2014
 * All rights reserved.
 *
 * @par
 * Software that is described herein is for illustrative purposes only
 * which provides customers with programming information regarding the
 * LPC products.  This software is supplied "AS IS" without any warranties of
 * any kind, and NXP Semiconductors and its licensor disclaim any and
 * all warranties, express or implied, including all implied warranties of
 * merchantability, fitness for a particular purpose and non-infringement of
 * intellectual property rights.  NXP Semiconductors assumes no responsibility
 * or liability for the use of the software, conveys no license or rights under any
 * patent, copyright, mask work right, or any other intellectual property rights in
 * or to any products. NXP Semiconductors reserves the right to make changes
 * in the software without notification. NXP Semiconductors also makes no
 * representation or warranty that such application will be suitable for the
 * specified use without further testing or modification.
 *
 * @par
 * Permission to use, copy, modify, and distribute this software and its
 * documentation is hereby granted, under NXP Semiconductors' and its
 * licensor's relevant copyrights in the software, without fee, provided that it
 * is used in conjunction with NXP Semiconductors microcontrollers.  This
 * copyright, permission, and disclaimer notice must appear in all copies of
 * this code.
 */

#include "board.h"
#include "FreeRTOS.h"
#include "task.h"

#define Neither		2
#define PUERTO_0    (uint32_t) 0
#define PIN_SDA1	(uint32_t) 19 //en nuestro stick el pin que esta asociado al sda de la memoria es el P0.19
#define PIN_SCL1	(uint32_t) 20 //idem anterior P0.20
#define I2C_FUNC	(uint32_t) 0x03 //la funcion 3 de los pines P0.19 t P0.20 es la de I2C
#define SLAVE_ADDR  0x50 //ya que el primer bit es de start, los 4 siguientes son de control (1010 para la flia 24lc64) y los 3 restantes del chip select (en nuestro stick estan puestos a 0 todos)

/* Sets up system hardware */
static void prvSetupHardware(void)
{
	SystemCoreClockUpdate();
	Board_Init();

	/* Initial LED0 state is off */
	Board_LED_Set(0, false);
}

static void EscribirYLeerEeprom(void *pvParameters) {

	int breakpoint = 0;
	uint8_t valor=26; //defino el valor a almacenar, debera ser de 8 bits
	uint8_t dato[]={0x00,0x00,valor} ; //defino el vector que utilizare para enviar a la memoria por i2c, el contenido de este vector sera: dir parte alta, dir parte baja, valor a enviar
	uint8_t memoria[]= {0x00,0x00}; //defino el vector de direccion de memoria que usare para leer
	uint8_t recibido=0; //variable en la cual almacenare el contenido de lo leido por la memoria

	while (1) {
		Chip_I2C_MasterSend(I2C1,SLAVE_ADDR,dato,sizeof(dato)); //mando por i2c parte baja, alta y valor
		vTaskDelay(10);		//para esperar a que guarde en memoria el dato (del orden de 1 a 5 ms) por las dudas 10ms
		Chip_I2C_MasterSend(I2C1,SLAVE_ADDR,memoria,sizeof(memoria)); //posiciono en memoria solamente direccion de mem alta y baja
		Chip_I2C_MasterRead(I2C1,SLAVE_ADDR,&recibido,sizeof(recibido)); //leo el valor

		breakpoint = 1;
	}
}


void  I2C1_IRQHandler (void)
{
	Chip_I2C_MasterStateHandler(I2C1); //tenemos que especificar que handler se encargara de la comunicacion I2C
}


int main(void)
{
	prvSetupHardware();

	Chip_IOCON_Init(LPC_IOCON);
	Chip_IOCON_PinMux(LPC_IOCON, PUERTO_0, PIN_SDA1, Neither, I2C_FUNC);
	Chip_IOCON_PinMux(LPC_IOCON, PUERTO_0, PIN_SCL1, Neither, I2C_FUNC);
	Chip_IOCON_EnableOD(LPC_IOCON, PUERTO_0, PIN_SDA1); //habilita open drain
	Chip_IOCON_EnableOD(LPC_IOCON, PUERTO_0, PIN_SCL1); //habilita open drain

	Chip_I2C_Init (I2C1);
	Chip_I2C_SetClockRate( I2C1, 100000);

	Chip_I2C_SetMasterEventHandler (I2C1, Chip_I2C_EventHandler); //inicializamos el handler que se encargara de la interrupcion

	/* LED2 toggle thread */
	xTaskCreate(EscribirYLeerEeprom, (signed char *) "EscribirYLeerEeprom",
				configMINIMAL_STACK_SIZE, NULL, (tskIDLE_PRIORITY + 1UL),
				(xTaskHandle *) NULL);

	NVIC_EnableIRQ(I2C1_IRQn);

	/* Start the scheduler */
	vTaskStartScheduler();

	/* Should never arrive here */
	return 1;
}

/**
 * @}
 */
