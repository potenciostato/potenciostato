/*
 * @brief ADC example
 * This example show how to  the ADC in 3 mode : Polling, Interrupt and DMA
 *
 * @note
 * Copyright(C) NXP Semiconductors, 2014
 * All rights reserved.
 *
 * @par
 * Software that is described herein is for illustrative purposes only
 * which provides customers with programming information regarding the
 * LPC products.  This software is supplied "AS IS" without any warranties of
 * any kind, and NXP Semiconductors and its licensor disclaim any and
 * all warranties, express or implied, including all implied warranties of
 * merchantability, fitness for a particular purpose and non-infringement of
 * intellectual property rights.  NXP Semiconductors assumes no responsibility
 * or liability for the use of the software, conveys no license or rights under any
 * patent, copyright, mask work right, or any other intellectual property rights in
 * or to any products. NXP Semiconductors reserves the right to make changes
 * in the software without notification. NXP Semiconductors also makes no
 * representation or warranty that such application will be suitable for the
 * specified use without further testing or modification.
 *
 * @par
 * Permission to use, copy, modify, and distribute this software and its
 * documentation is hereby granted, under NXP Semiconductors' and its
 * licensor's relevant copyrights in the software, without fee, provided that it
 * is used in conjunction with NXP Semiconductors microcontrollers.  This
 * copyright, permission, and disclaimer notice must appear in all copies of
 * this code.
 */

#include "board.h"

/*****************************************************************************
 * Private types/enumerations/variables
 ****************************************************************************/
#define ADC_CHANNEL ADC_CH0
#define LPC_ADC_ID LPC_ADC

static ADC_CLOCK_SETUP_T ADCSetup;
/*****************************************************************************
 * Public types/enumerations/variables
 ****************************************************************************/

/*****************************************************************************
 * Private functions
 ****************************************************************************/

/* Polling routine for ADC example */
static void App_Polling_Test(void)
{
	uint16_t dataADC;

	/* Select using burst mode or not */

	Chip_ADC_SetBurstCmd(LPC_ADC_ID, DISABLE);


	Chip_ADC_SetStartMode(LPC_ADC_ID, ADC_START_NOW, ADC_TRIGGERMODE_RISING);

		/* Waiting for A/D conversion complete */
	if (Chip_ADC_ReadStatus(LPC_ADC_ID, ADC_CHANNEL, ADC_DR_DONE_STAT) == SET) {
		/* Read ADC value */
		Chip_ADC_ReadValue(LPC_ADC_ID, ADC_CHANNEL, &dataADC);
	}

	Chip_ADC_SetBurstCmd(LPC_ADC_ID, DISABLE);

}

/*****************************************************************************
 * Public functions
 *****************************************************************************

/**
 * @brief	Main routine for ADC example
 * @return	Nothing
 */
int main(void)
{
	uint32_t bitRate = ADC_MAX_SAMPLE_RATE;

	SystemCoreClockUpdate();
	Board_Init();

	/*	Chip_IOCON_PinMux(0, 25, IOCON_ADMODE_EN, IOCON_FUNC1); */
	/*ADC Init */
	Chip_ADC_Init(LPC_ADC_ID, &ADCSetup);
	Chip_ADC_EnableChannel(LPC_ADC_ID, ADC_CHANNEL, ENABLE);

	Chip_ADC_SetSampleRate(LPC_ADC_ID, &ADCSetup, bitRate);

	while (1) {
		App_Polling_Test();
	}
	return 0;
}

/**
 * @}
 */
