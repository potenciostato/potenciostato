/*
 * Sintetizador Grupo 1
 *
 */

#include <board.h>
#include <FreeRTOS.h>
#include <task.h>
#include <chip.h>
#include <semphr.h>
#include <queue.h>

#include "defines.h"

//#include "setup.c"



/*****************************************************************************
 * Private types/enumerations/variables
 ****************************************************************************/
#define LARGO_COLA  1
xQueueHandle cola_estado; //creamos un manejador de colas global.


void Leer_Teclado(void); void Prender_Leds(void);
/*****************************************************************************
 * Public types/enumerations/variables
 ****************************************************************************/

/*****************************************************************************
 * Private functions
 ****************************************************************************/

/* Funcion de setup de hardware */
static void prvSetupHardware(void)
{
	uint32_t timerfreq;

	SystemCoreClockUpdate();
	Board_Init();

	timerfreq= Chip_Clock_GetSystemClockRate();

    Chip_IOCON_PinMux(LPC_IOCON, PORTVOL1, PINVOL1, MD_PLN, IOCON_FUNC0); //Configuro la funcion del pin
    Chip_GPIO_SetPinDIRInput(LPC_GPIO, PORTVOL1, PINVOL1); //Configuro como salida el pin
    Chip_IOCON_PinMux(LPC_IOCON, PORTVOL3, PINVOL3, MD_PLN, IOCON_FUNC0); //Configuro la funcion del pin
    Chip_GPIO_SetPinDIRInput(LPC_GPIO, PORTVOL3, PINVOL3); //Configuro como salida el pin

    Chip_IOCON_PinMux(LPC_IOCON, PORTFCI1, PINFCI1, MD_PLN, IOCON_FUNC0); //Configuro la funcion del pin
    Chip_GPIO_SetPinDIRInput(LPC_GPIO, PORTFCI1, PINFCI1); //Configuro como salida el pin
    Chip_IOCON_PinMux(LPC_IOCON, PORTFCI3, PINFCI3, MD_PLN, IOCON_FUNC0); //Configuro la funcion del pin
    Chip_GPIO_SetPinDIRInput(LPC_GPIO, PORTFCI3, PINFCI3); //Configuro como salida el pin

    Chip_IOCON_PinMux(LPC_IOCON, PORTFCS1, PINFCS1, MD_PLN, IOCON_FUNC0); //Configuro la funcion del pin
    Chip_GPIO_SetPinDIRInput(LPC_GPIO, PORTFCS1, PINFCS1); //Configuro como salida el pin
    Chip_IOCON_PinMux(LPC_IOCON, PORTFCS3, PINFCS3, MD_PLN, IOCON_FUNC0); //Configuro la funcion del pin
    Chip_GPIO_SetPinDIRInput(LPC_GPIO, PORTFCS3, PINFCS3); //Configuro como salida el pin

    Chip_IOCON_PinMux(LPC_IOCON, PORTOVER1, PINOVER1, MD_PLN, IOCON_FUNC0); //Configuro la funcion del pin
    Chip_GPIO_SetPinDIRInput(LPC_GPIO, PORTOVER1, PINOVER1); //Configuro como salida el pin
    Chip_IOCON_PinMux(LPC_IOCON, PORTOVER3, PINOVER3, MD_PLN, IOCON_FUNC0); //Configuro la funcion del pin
    Chip_GPIO_SetPinDIRInput(LPC_GPIO, PORTOVER3, PINOVER3); //Configuro como salida el pin

    Chip_IOCON_PinMux(LPC_IOCON, PORTATT1, PINATT1, MD_PLN, IOCON_FUNC0); //Configuro la funcion del pin
    Chip_GPIO_SetPinDIRInput(LPC_GPIO, PORTATT1, PINATT1); //Configuro como salida el pin
    Chip_IOCON_PinMux(LPC_IOCON, PORTATT3, PINATT3, MD_PLN, IOCON_FUNC0); //Configuro la funcion del pin
    Chip_GPIO_SetPinDIRInput(LPC_GPIO, PORTATT3, PINATT3); //Configuro como salida el pin

    Chip_IOCON_PinMux(LPC_IOCON, PORTDELAY1, PINDELAY1, MD_PLN, IOCON_FUNC0); //Configuro la funcion del pin
    Chip_GPIO_SetPinDIRInput(LPC_GPIO, PORTDELAY1, PINDELAY1); //Configuro como salida el pin
    Chip_IOCON_PinMux(LPC_IOCON, PORTDELAY3, PINDELAY3, MD_PLN, IOCON_FUNC0); //Configuro la funcion del pin
    Chip_GPIO_SetPinDIRInput(LPC_GPIO, PORTDELAY3, PINDELAY3); //Configuro como salida el pin

    Chip_IOCON_PinMux(LPC_IOCON, PORTBOTONES, PINSENO, MD_PLN, IOCON_FUNC0); //Configuro la funcion del pin
    Chip_GPIO_SetPinDIRInput(LPC_GPIO, PORTBOTONES, PINSENO); //Configuro como salida el pin
    Chip_IOCON_PinMux(LPC_IOCON, PORTBOTONES, PINTRIA, MD_PLN, IOCON_FUNC0); //Configuro la funcion del pin
    Chip_GPIO_SetPinDIRInput(LPC_GPIO, PORTBOTONES, PINTRIA); //Configuro como salida el pin
    Chip_IOCON_PinMux(LPC_IOCON, PORTBOTONES, PINCUAD, MD_PLN, IOCON_FUNC0); //Configuro la funcion del pin
    Chip_GPIO_SetPinDIRInput(LPC_GPIO, PORTBOTONES, PINCUAD); //Configuro como salida el pin
    Chip_IOCON_PinMux(LPC_IOCON, PORTBOTONES, PINSIER, MD_PLN, IOCON_FUNC0); //Configuro la funcion del pin
    Chip_GPIO_SetPinDIRInput(LPC_GPIO, PORTBOTONES, PINSIER); //Configuro como salida el pin

    Chip_IOCON_PinMux(LPC_IOCON, PORTBOTONES, PINPA, MD_PLN, IOCON_FUNC0); //Configuro la funcion del pin
    Chip_GPIO_SetPinDIRInput(LPC_GPIO, PORTBOTONES, PINPA); //Configuro como salida el pin
    Chip_IOCON_PinMux(LPC_IOCON, PORTBOTONES, PINPB, MD_PLN, IOCON_FUNC0); //Configuro la funcion del pin
    Chip_GPIO_SetPinDIRInput(LPC_GPIO, PORTBOTONES, PINPB); //Configuro como salida el pin
    Chip_IOCON_PinMux(LPC_IOCON, PORTBOTONES, PINPAB, MD_PLN, IOCON_FUNC0); //Configuro la funcion del pin
    Chip_GPIO_SetPinDIRInput(LPC_GPIO, PORTBOTONES, PINPAB); //Configuro como salida el pin

    Chip_IOCON_PinMux(LPC_IOCON, 		PORT_EXCT1, PIN_EXCT1, 		MD_PLN, IOCON_FUNC0);	//Configuramos la funcion del los pines de excitacion
    Chip_GPIO_SetPinDIROutput(LPC_GPIO, PORT_EXCT1, PIN_EXCT1);							//Configuramos los pines como salida
    Chip_IOCON_PinMux(LPC_IOCON, 		PORT_EXCT2, PIN_EXCT2, 		MD_PLN, IOCON_FUNC0);
    Chip_GPIO_SetPinDIROutput(LPC_GPIO, PORT_EXCT2, PIN_EXCT2);
    Chip_IOCON_PinMux(LPC_IOCON, 		PORT_EXCT3, PIN_EXCT3, 		MD_PLN, IOCON_FUNC0);
    Chip_GPIO_SetPinDIROutput(LPC_GPIO, PORT_EXCT3, PIN_EXCT3);
    Chip_IOCON_PinMux(LPC_IOCON, 		PORT_EXCT4, PIN_EXCT4, 		MD_PLN, IOCON_FUNC0);
    Chip_GPIO_SetPinDIROutput(LPC_GPIO, PORT_EXCT4, PIN_EXCT4);
    Chip_IOCON_PinMux(LPC_IOCON, 		PORT_EXCT5, PIN_EXCT5, 		MD_PLN, IOCON_FUNC0);
    Chip_GPIO_SetPinDIROutput(LPC_GPIO, PORT_EXCT5, PIN_EXCT5);
    Chip_IOCON_PinMux(LPC_IOCON, 		PORT_EXCT6, PIN_EXCT6, 		MD_PLN, IOCON_FUNC0);
    Chip_GPIO_SetPinDIROutput(LPC_GPIO, PORT_EXCT6, PIN_EXCT6);
    Chip_IOCON_PinMux(LPC_IOCON, 		PORT_EXCT7, PIN_EXCT7, 		MD_PLN, IOCON_FUNC0);
    Chip_GPIO_SetPinDIROutput(LPC_GPIO, PORT_EXCT7, PIN_EXCT7);
    Chip_IOCON_PinMux(LPC_IOCON, 		PORT_EXCT8, PIN_EXCT8, 		MD_PLN, IOCON_FUNC0);
    Chip_GPIO_SetPinDIROutput(LPC_GPIO, PORT_EXCT8, PIN_EXCT8);

    Chip_IOCON_PinMux(LPC_IOCON, 		PORT_SENS1, PIN_SENS1, 		MD_PLN, IOCON_FUNC0);		//Configuramos la funcion de los pines del teclado
    Chip_GPIO_SetPinDIRInput(LPC_GPIO, 	PORT_SENS1, PIN_SENS1);								//Configuramos los pines como entrada
    Chip_IOCON_PinMux(LPC_IOCON, 		PORT_SENS2, PIN_SENS2, 		MD_PLN, IOCON_FUNC0);
    Chip_GPIO_SetPinDIRInput(LPC_GPIO, 	PORT_SENS2, PIN_SENS2);
    Chip_IOCON_PinMux(LPC_IOCON, 		PORT_SENS3, PIN_SENS3, 		MD_PLN, IOCON_FUNC0);
    Chip_GPIO_SetPinDIRInput(LPC_GPIO, 	PORT_SENS3, PIN_SENS3);
    Chip_IOCON_PinMux(LPC_IOCON, 		PORT_SENS4, PIN_SENS4, 		MD_PLN, IOCON_FUNC0);
    Chip_GPIO_SetPinDIRInput(LPC_GPIO, 	PORT_SENS4, PIN_SENS4);

    Chip_TIMER_Init(LPC_TIMER2);								//Inicializamos el Timer
    Chip_Clock_SetPCLKDiv(SYSCTL_CLOCK_TIMER2, SYSCTL_CLKDIV_1);	//Le ponemos la division al preescaler en 1
    Chip_TIMER_PrescaleSet(LPC_TIMER2, 0); 						//porque si le pongo pclk en 1 y prescale en 0 divido por (pr+1) = 1
    Chip_TIMER_SetMatch(LPC_TIMER2, 0, (timerfreq/1000)); 				//cada 1mS
    Chip_TIMER_MatchEnableInt(LPC_TIMER2, 0); 					//Habilitamos el match

    Chip_TIMER_ResetOnMatchEnable(LPC_TIMER2, 0); 								//Configuramos que resetee al habilitarse
    Chip_TIMER_StopOnMatchDisable(LPC_TIMER2, 0); 									//Configuramos que pare al deshabilitarse
    Chip_TIMER_ExtMatchControlSet(LPC_TIMER2, 0, TIMER_EXTMATCH_DO_NOTHING, 0); //Configuro para que no haga nada con el pin asociado

    Chip_TIMER_Enable(LPC_TIMER2);
}
void TIMER2_IRQHandler(void)
{

	portBASE_TYPE pxHigherPriorityTaskWoken = pdFALSE;

	if(Chip_TIMER_MatchPending(LPC_TIMER2,0))
	{
		Chip_TIMER_ClearMatch(LPC_TIMER2,0);

		Leer_Teclado();
		Prender_Leds();

//		//Give
//		if(boton1){
//			xSemaphoreGiveFromISR(sem_led1,&pxHigherPriorityTaskWoken);
//		}else{
//			xSemaphoreGiveFromISR(sem_led2,&pxHigherPriorityTaskWoken);
//		}

		portEND_SWITCHING_ISR(pxHigherPriorityTaskWoken);//cuando cierre la ISR forzara un cambio de contexto si la variable px higherpriority cambia a true
	}
}
void Leer_Teclado(void){
	int boton1aux = 0;
	int boton2aux = 0;
	int boton3aux = 0;
	int boton4aux = 0;
	int i = 0;
	int a = 0;

	uint32_t estado = 0;

	for (a=0;a<8;a++){

		//Deshabilito todas las "columnas"
		for(i=0;i<8;i++)
			Chip_GPIO_SetPinOutHigh(LPC_GPIO, PORTS_EXCT(i), PINS_EXCT(i));

		boton1aux = 0;
		boton2aux = 0;
		boton3aux = 0;
		boton4aux = 0;

		//habilito las mediciones para 1 columna de 4 teclas
		Chip_GPIO_SetPinOutLow(LPC_GPIO, PORTS_EXCT(a), PINS_EXCT(a)); 	//para a = 0 habilita 1, 9,17,25;
																		//para a = 1 habilita 2,10,18,26; y asi...

		//Leemos las teclas
		boton1aux = !Chip_GPIO_GetPinState(LPC_GPIO, PORT_SENS1, PIN_SENS1); //chequeo el estado del pin de las teclas habilitadas
		boton2aux = !Chip_GPIO_GetPinState(LPC_GPIO, PORT_SENS2, PIN_SENS2); //en la primer pasada toman las teclas 1, 9, 17 y 25; la segunda 2,10,18 y 26; y asi...
		boton3aux = !Chip_GPIO_GetPinState(LPC_GPIO, PORT_SENS3, PIN_SENS3);
		boton4aux = !Chip_GPIO_GetPinState(LPC_GPIO, PORT_SENS4, PIN_SENS4);

		estado |= ((boton3aux<<(a+6))|(boton2aux<<(a+3))|(boton1aux<<(a)));

	}

	xQueueSendToBack(cola_estado, &estado, (portTickType) 0);

}
void Prender_Leds(void){

	int i = 0;
	uint32_t estado = 0;

	if (uxQueueMessagesWaiting(cola_estado)==1){

		xQueueReceive( cola_estado, &estado, (portTickType) 0 );

		i= 2; //para tener un breakpoint
		/*for(i=0; i<10; i++)
		{
			Chip_GPIO_SetPinOutLow(LPC_GPIO, PORTS_LED(i), PINS_LED(i));
		}

		for (i=0;i<9;i++){
			if ((estado & (1<<i)) == (1<<i))
				Chip_GPIO_SetPinOutHigh(LPC_GPIO, PORTS_LED(i), PINS_LED(i));
		}*/
	}

}
static void vInicializarNVIC(void *pvParameters) {

	NVIC_ClearPendingIRQ(TIMER2_IRQn);
	NVIC_EnableIRQ(TIMER2_IRQn);

	while (1) {
		vTaskDelete(NULL);
	}
}


/*****************************************************************************
 * Public functions
 ****************************************************************************/

/**
 * @brief	main routine for FreeRTOS blinky example
 * @return	Nothing, function should not exit
 */
int main(void)
{
	prvSetupHardware();


	cola_estado = xQueueCreate(LARGO_COLA, sizeof(uint32_t)); 	//Creamos la cola que contendra el estado de la matriz del teclado,
																//si apreto la tecla 1 se pone en 1 el bit menos significativo y
																//si apreto la tecla 32 el mas signficativo

	xTaskCreate(vInicializarNVIC, (signed char *) "vInicializarNVIC",
				configMINIMAL_STACK_SIZE, NULL, (tskIDLE_PRIORITY + 1UL),
				(xTaskHandle *) NULL);

	/* Start the scheduler */
	vTaskStartScheduler();

	/* Should never arrive here */
	return 1;
}

/**
 * @}
 */
