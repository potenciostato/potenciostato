/*
 * @brief FreeRTOS Blinky example
 *
 * @note
 * Copyright(C) NXP Semiconductors, 2014
 * All rights reserved.
 *
 * @par
 * Software that is described herein is for illustrative purposes only
 * which provides customers with programming information regarding the
 * LPC products.  This software is supplied "AS IS" without any warranties of
 * any kind, and NXP Semiconductors and its licensor disclaim any and
 * all warranties, express or implied, including all implied warranties of
 * merchantability, fitness for a particular purpose and non-infringement of
 * intellectual property rights.  NXP Semiconductors assumes no responsibility
 * or liability for the use of the software, conveys no license or rights under any
 * patent, copyright, mask work right, or any other intellectual property rights in
 * or to any products. NXP Semiconductors reserves the right to make changes
 * in the software without notification. NXP Semiconductors also makes no
 * representation or warranty that such application will be suitable for the
 * specified use without further testing or modification.
 *
 * @par
 * Permission to use, copy, modify, and distribute this software and its
 * documentation is hereby granted, under NXP Semiconductors' and its
 * licensor's relevant copyrights in the software, without fee, provided that it
 * is used in conjunction with NXP Semiconductors microcontrollers.  This
 * copyright, permission, and disclaimer notice must appear in all copies of
 * this code.
 */

#include <board.h>
#include <FreeRTOS.h>
#include <task.h>
#include <chip.h>
#include <semphr.h>
#include <queue.h>

#include "defines.h"

/*
 * Version practica_final1 con el agregado de la EEPROM y un timer mas que por medio de un semaforo habilita una tarea cada 5 minutos
 * (al momento t=0 no lo hace, si no que si o si a los 5 minutos)
 * y esa tarea guarda la cantidad de veces que se cambio el pwm (p ejemplo) en la eeprom, para, cuando inicia el programa guardar ese valor
 * variable de 32 bits
 * Notas: ver como guardar 32bits de a 8
 *
 * Funcionamiento:
 * Al iniciar el programa deberá leer lo que hay si existe el valor 0x55 en el primer byte de informacion quiere decir que
 * el programa ya fue corrido y que debera leer el valor que sigue (32 bits con la cantidad grabada)
 * Ahora bien, si no existe ese valor en el primer byte, al pasar los primeros 5 minutos se debera guardar pisando el valor que tenia
 * la memoria y poniendo este valor "llave" de 0x55 en el primer byte
 * y, consecutivamente ir guardando el valor que va actualizando cada 5 minutos.
 *
 */

/*****************************************************************************
 * Private types/enumerations/variables
 ****************************************************************************/

/*****************************************************************************
 * Public types/enumerations/variables
 ****************************************************************************/

/*****************************************************************************
 * Private functions
 ****************************************************************************/
#define ADC_CHANNEL ADC_CH0
#define LPC_ADC_ID LPC_ADC

static ADC_CLOCK_SETUP_T ADCSetup;

#define LARGO_COLA  1
xQueueHandle cola_lectura; //creamos un manejador de colas global.
xQueueHandle cola_boton;

xTaskHandle MaquinasEstados;
xTaskHandle LeerADC;
xTaskHandle LeerBoton;
xTaskHandle SuspenderPrograma;

xSemaphoreHandle semaforo;

void TIMER1_IRQHandler(void)
{
	if (Chip_TIMER_MatchPending(LPC_TIMER1, 0)) {
		Chip_TIMER_ClearMatch(LPC_TIMER1, 0);
		Chip_GPIO_SetPinOutLow(LPC_GPIO,0,22);
	}
	if (Chip_TIMER_MatchPending(LPC_TIMER1, 1)) {
		Chip_TIMER_ClearMatch(LPC_TIMER1, 1);
		Chip_GPIO_SetPinOutHigh(LPC_GPIO,0,22);
	}
}
void TIMER2_IRQHandler(void)
{
	static uint32_t cuenta = 0;
	if (Chip_TIMER_MatchPending(LPC_TIMER2, 0)) {
		Chip_TIMER_ClearMatch(LPC_TIMER2, 0);

		if (cuenta >= 5){ //para probar, luego va 360
			cuenta = 0;
			//guardar en memoria
		}
		else
			cuenta ++;
	}
}

/*CODIGO PIOLA PARA DAR UN SEMAFORO DESDE UNA INTERRUPCION
 * void TIMER0_IRQHandler(void)
{

	portBASE_TYPE pxHigherPriorityTaskWoken = pdFALSE;
	if(Chip_TIMER_MatchPending(LPC_TIMER0,0))
	{
		Chip_TIMER_ClearMatch(LPC_TIMER0,0);

		//Give
		xSemaphoreGiveFromISR(sem_led,&pxHigherPriorityTaskWoken);
		portEND_SWITCHING_ISR(pxHigherPriorityTaskWoken);//cuando cierre la ISR forzara un cambio de contexto si la variable px higherpriority cambia a true
	}
}
 *
 */

/* Sets up system hardware */
static void prvSetupHardware(void)
{

	uint32_t timerfreq;

	SystemCoreClockUpdate();
	Chip_GPIO_Init(LPC_GPIO);
	Chip_IOCON_Init(LPC_IOCON);

	timerfreq= Chip_Clock_GetSystemClockRate();

	Chip_IOCON_PinMux(LPC_IOCON, PORTBOTON, PINBOTON, MD_PLN, IOCON_FUNC0); //Configuro la funcion del pin
	Chip_GPIO_SetPinDIRInput(LPC_GPIO, PORTBOTON, PINBOTON); //Configuro como entrada el pin

	Chip_IOCON_PinMux(LPC_IOCON, PORTPUERTA, PINPUERTA, MD_PLN, IOCON_FUNC0); //Configuro la funcion del pin
	Chip_GPIO_SetPinDIRInput(LPC_GPIO, PORTPUERTA, PINPUERTA); //Configuro como entrada el pin

	Chip_IOCON_PinMux(LPC_IOCON, 0, 22, MD_PLN, IOCON_FUNC0); //Configuro la funcion del pin
	Chip_GPIO_SetPinDIROutput(LPC_GPIO, 0, 22); //Configuro como entrada el pin

	/* Enable timer 1 clock */
	Chip_TIMER_Init(LPC_TIMER1);

	/* Timer rate is system clock rate */
	timerfreq = Chip_Clock_GetSystemClockRate();

	/* Timer setup for match and interrupt at TICKRATE_HZ */
	Chip_TIMER_Reset(LPC_TIMER1);

	Chip_TIMER_MatchEnableInt(LPC_TIMER1, 0);
	Chip_TIMER_SetMatch(LPC_TIMER1, 0, timerfreq/10000);
	Chip_TIMER_ResetOnMatchEnable(LPC_TIMER1, 0);

	Chip_TIMER_MatchEnableInt(LPC_TIMER1, 1);
	Chip_TIMER_SetMatch(LPC_TIMER1, 1, timerfreq/11000);

	/* Enable timer 2 clock */
	Chip_TIMER_Init(LPC_TIMER2);

	Chip_TIMER_Reset(LPC_TIMER2);

	Chip_TIMER_MatchEnableInt(LPC_TIMER2, 0);
	Chip_TIMER_SetMatch(LPC_TIMER2, 0, timerfreq); //cada 1 segundo
	Chip_TIMER_ResetOnMatchEnable(LPC_TIMER2, 0);

	Chip_TIMER_Enable(LPC_TIMER2);


}


static void vLeerBoton(void *pvParameters) {

	int boton;

	while(1){

		// BOTON ON//OFF
		if (!Chip_GPIO_GetPinState(LPC_GPIO, PORTBOTON, PINBOTON)==1){

			if (uxQueueMessagesWaiting(cola_boton)==1){
				xQueueReceive( cola_boton, &boton, (portTickType) 0 );
			}
			boton=APRETADO;
			xQueueSendToBack( cola_boton, &boton, (portTickType) 0);
		}else{
			if (uxQueueMessagesWaiting(cola_boton)==1){
				xQueueReceive( cola_boton, &boton, (portTickType) 0 );
			}
			boton=SINAPRETAR;
			xQueueSendToBack( cola_boton, &boton, (portTickType) 0);
		}

		taskYIELD();
	}
}
static void vLeerADC(void *pvParameters) {

	uint16_t lectura = 0;
	uint32_t bitRate = ADC_MAX_SAMPLE_RATE;

	/* Select using burst mode or not */

	Chip_ADC_Init(LPC_ADC_ID, &ADCSetup);
	Chip_ADC_EnableChannel(LPC_ADC_ID, ADC_CHANNEL, ENABLE);

	Chip_ADC_SetSampleRate(LPC_ADC_ID, &ADCSetup, bitRate);

	Chip_ADC_SetBurstCmd(LPC_ADC_ID, DISABLE);



	while (1){
		Chip_ADC_SetStartMode(LPC_ADC_ID, ADC_START_NOW, ADC_TRIGGERMODE_RISING);

		/* Waiting for A/D conversion complete */
		if (Chip_ADC_ReadStatus(LPC_ADC_ID, ADC_CHANNEL, ADC_DR_DONE_STAT) == SET) {
			/* Read ADC value */
			Chip_ADC_ReadValue(LPC_ADC_ID, ADC_CHANNEL, &lectura);

			if (uxQueueMessagesWaiting(cola_lectura)==1){
				xQueueReceive( cola_lectura, &lectura, (portTickType) 0 );
			}
			xQueueSendToBack( cola_lectura, &lectura, (portTickType) 0);
		}
		taskYIELD();
	}

}
static void vSuspenderPrograma(void *pvParameters) {

	int boton = SINAPRETAR;
	uint16_t lectura;

	static int estado = ACTIVO;

	while(1){
		if (uxQueueMessagesWaiting(cola_boton)==1){
			xQueuePeek(cola_boton, &boton, (portTickType) 0 );
			if (boton == APRETADO && estado == ACTIVO){

				estado = SUSPENDIENDO;

				vTaskSuspend(MaquinasEstados);
				vTaskSuspend(LeerADC);

				Chip_TIMER_Disable(LPC_TIMER1);
				NVIC_ClearPendingIRQ(TIMER1_IRQn);
				NVIC_DisableIRQ(TIMER1_IRQn);

				Chip_ADC_EnableChannel(LPC_ADC_ID, ADC_CHANNEL, DISABLE);
				Chip_ADC_DeInit(LPC_ADC_ID);

				Chip_GPIO_SetPinOutHigh(LPC_GPIO,0,22);
				//Apago_MOTOR();

				while (uxQueueMessagesWaiting(cola_lectura)==1){
					xQueueReceive( cola_lectura, &lectura, (portTickType) 0 );
				}

			}
			if (boton == SINAPRETAR && estado == SUSPENDIENDO){
				estado = SUSPENDIDO;
			}
			if (boton == APRETADO && estado == SUSPENDIDO){

				Chip_ADC_Init(LPC_ADC_ID, &ADCSetup);
				Chip_ADC_EnableChannel(LPC_ADC_ID, ADC_CHANNEL, ENABLE);

				Chip_TIMER_Enable(LPC_TIMER1);
				NVIC_ClearPendingIRQ(TIMER1_IRQn);
				NVIC_EnableIRQ(TIMER1_IRQn);

				vTaskResume(MaquinasEstados);
				vTaskResume(LeerADC);

				estado = ACTIVANDO;
			}
			if (boton == SINAPRETAR && estado == ACTIVANDO){
				estado = ACTIVO;
			}
		}
		vTaskDelay(100);
	}
}


static void vMaquinasEstados(void *pvParameters) {

	uint16_t lectura; //adc
	static int estado_maq_motor = ESTADO_INICIAL_MOTOR; //estado de la maquina motor
	static int estado_maq_pwm = ESTADO_INICIAL_PWM; //estado de la maquina pwm
	int temp_motor = TEMP_MOTOR_SINCAMBIO; //mappeado del adc en una variable con valores unicos
	int temp_pwm = TEMP_PWM_SINCAMBIO;
	int puerta = PUERTA_SINCAMBIO;

	uint32_t timerfreq;


	timerfreq=Chip_Clock_GetSystemClockRate();


	while(1){
		//maquina estados motor:
		if (estado_maq_motor >= ESTADO_MAXIMO_MOTOR){
			estado_maq_motor = ESTADO_INICIAL_MOTOR;
		}
		if (estado_maq_pwm >= ESTADO_MAXIMO_PWM){
			estado_maq_pwm = ESTADO_INICIAL_PWM;
		}

		if (uxQueueMessagesWaiting(cola_lectura)==1){
			xQueueReceive( cola_lectura, &lectura, (portTickType) 0 );
		}
//		if (!Chip_GPIO_GetPinState(LPC_GPIO, PORTPUERTA, PINPUERTA)==1){
//			puerta = PUERTA_ABIERTA;
//		}else{
//			puerta = PUERTA_CERRADA;
//		}
		puerta = PUERTA_CERRADA;


		if (lectura > 400*8)
			temp_motor = TEMP_MOTOR_AMB;
		if (lectura > 250*8 && lectura <= 400*8)
			temp_motor = TEMP_MOTOR_FRIO;
		if (lectura <= 250*8)
			temp_motor = TEMP_MOTOR_MUYFRIO;

		if (lectura > 450*8)
			temp_pwm = TEMP_PWM_TIBIO;
		if (lectura <= 450*8)
			temp_pwm = TEMP_PWM_FRESCO;
		if (lectura <= 300*8)
			temp_pwm = TEMP_PWM_FRIO;
		if (lectura <= 250*8)
			temp_pwm = TEMP_PWM_MUYFRIO;

		switch(estado_maq_motor)
		{
			case ESTADO_INICIAL_MOTOR:
//				Inicio_MOTOR();
				if (temp_motor == TEMP_MOTOR_AMB || temp_motor == TEMP_MOTOR_FRIO){
					estado_maq_motor = ESTADO_MOTOR_PRENDIDO;

				}
				if (temp_motor == TEMP_MOTOR_MUYFRIO){
					estado_maq_motor = ESTADO_MOTOR_APAGADO;
				}
				break;
			case ESTADO_MOTOR_PRENDIDO:
//				Prendo_MOTOR();
				if (temp_motor == TEMP_MOTOR_MUYFRIO){
					estado_maq_motor = ESTADO_MOTOR_APAGADO;
				}
				break;
			case ESTADO_MOTOR_APAGADO:
//				Apago_MOTOR();
				if (temp_motor == TEMP_MOTOR_AMB){
					estado_maq_motor = ESTADO_MOTOR_PRENDIDO;
				}
				break;
		}

		switch(estado_maq_pwm)
		{
			case ESTADO_INICIAL_PWM:
//				Inicio_PWM();
				if (temp_pwm == TEMP_PWM_TIBIO || puerta == PUERTA_ABIERTA){
					estado_maq_pwm = ESTADO_PWM_APAGADO;
				}
				if ((temp_pwm <= TEMP_PWM_FRESCO) && puerta == PUERTA_CERRADA){
					estado_maq_pwm = ESTADO_PWM10;
				}
				break;
			case ESTADO_PWM10:
//				Seteo_PWM(10);
				Chip_TIMER_Enable(LPC_TIMER1);
				NVIC_ClearPendingIRQ(TIMER1_IRQn);
				NVIC_EnableIRQ(TIMER1_IRQn);
				Chip_TIMER_SetMatch(LPC_TIMER1, 1, timerfreq/100000);
				if ((temp_pwm <= TEMP_PWM_FRIO) && puerta == PUERTA_CERRADA){
					estado_maq_pwm = ESTADO_PWM25;
				}
				if ((temp_pwm > TEMP_PWM_FRESCO) || puerta == PUERTA_ABIERTA){
					estado_maq_pwm = ESTADO_PWM_APAGADO;
				}
				break;
			case ESTADO_PWM25:
//				Seteo_PWM(25);
				Chip_TIMER_Enable(LPC_TIMER1);
				NVIC_ClearPendingIRQ(TIMER1_IRQn);
				NVIC_EnableIRQ(TIMER1_IRQn);
				Chip_TIMER_SetMatch(LPC_TIMER1, 1, timerfreq/40000);
				if ((temp_pwm <= TEMP_PWM_MUYFRIO) && puerta == PUERTA_CERRADA){
					estado_maq_pwm = ESTADO_PWM50;
				}
				if ((temp_pwm > TEMP_PWM_FRIO) || puerta == PUERTA_ABIERTA){
					estado_maq_pwm = ESTADO_PWM_APAGADO;
				}
				break;
			case ESTADO_PWM50:
//				Seteo_PWM(50);
				Chip_TIMER_Enable(LPC_TIMER1);
				NVIC_ClearPendingIRQ(TIMER1_IRQn);
				NVIC_EnableIRQ(TIMER1_IRQn);
				Chip_TIMER_SetMatch(LPC_TIMER1, 1, timerfreq/20000);
				if ((temp_pwm > TEMP_PWM_MUYFRIO) || puerta == PUERTA_ABIERTA){
					estado_maq_pwm = ESTADO_PWM_APAGADO;
				}
				break;
			case ESTADO_PWM_APAGADO:
//				Apago_PWM();
				Chip_TIMER_Disable(LPC_TIMER1);
				NVIC_ClearPendingIRQ(TIMER1_IRQn);
				NVIC_DisableIRQ(TIMER1_IRQn);
				Chip_GPIO_SetPinOutHigh(LPC_GPIO,0,22);
				if ((temp_pwm <= TEMP_PWM_FRESCO) && puerta == PUERTA_CERRADA){
					estado_maq_pwm = ESTADO_PWM10;
				}
				break;
		}


		taskYIELD();
	}
}

/*****************************************************************************
 * Public functions
 ****************************************************************************/

/**
 * @brief	main routine for FreeRTOS blinky example
 * @return	Nothing, function should not exit
 */
int main(void)
{
	prvSetupHardware();

	semaforo = xSemaphoreCreateMutex();
	//xSemaphoreCreateCounting();
	cola_boton = xQueueCreate(LARGO_COLA, sizeof(uint32_t));
	cola_lectura = xQueueCreate(LARGO_COLA, sizeof(uint16_t));

	xTaskCreate(vMaquinasEstados, (signed char *) "MaquinasEstados",
					configMINIMAL_STACK_SIZE, NULL, (tskIDLE_PRIORITY + 1UL),
					(xTaskHandle *) &MaquinasEstados);

	xTaskCreate(vLeerADC, (signed char *) "LeerADC",
					configMINIMAL_STACK_SIZE, NULL, (tskIDLE_PRIORITY + 1UL),
					(xTaskHandle *) &LeerADC);

	xTaskCreate(vLeerBoton, (signed char *) "LeerBotones",
					configMINIMAL_STACK_SIZE, NULL, (tskIDLE_PRIORITY + 1UL),
					(xTaskHandle *) &LeerBoton);

	xTaskCreate(vSuspenderPrograma, (signed char *) "SuspenderPrograma",
					configMINIMAL_STACK_SIZE, NULL, (tskIDLE_PRIORITY + 1UL),
					(xTaskHandle *) &SuspenderPrograma);

	/* Enable timer interrupt */
	NVIC_ClearPendingIRQ(TIMER1_IRQn);
	NVIC_EnableIRQ(TIMER1_IRQn);

	/* Enable timer interrupt */
	NVIC_ClearPendingIRQ(TIMER2_IRQn);
	NVIC_EnableIRQ(TIMER2_IRQn);

	/* Start the scheduler */
	vTaskStartScheduler();

	/* Should never arrive here */
	return 1;
}

/**
 * @}
 */
