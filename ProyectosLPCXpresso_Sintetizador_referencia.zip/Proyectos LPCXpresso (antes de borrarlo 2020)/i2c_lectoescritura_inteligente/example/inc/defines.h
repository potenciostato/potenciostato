/*
 * defines.h
 *
 *  Created on: Nov 26, 2016
 *      Author: axellucas
 */

#ifndef DEFINES_H_
#define DEFINES_H_


#define SALIDA			1
#define ENTRADA			0

#define APRETADO		1
#define SINAPRETAR		0

#define ACTIVO 			0
#define SUSPENDIENDO	1
#define SUSPENDIDO		2
#define ACTIVANDO 		3

#define ESTADO_INICIAL_MOTOR 0
#define ESTADO_MOTOR_PRENDIDO 1
#define ESTADO_MOTOR_APAGADO 2
#define ESTADO_MAXIMO_MOTOR	3

#define ESTADO_INICIAL_PWM 0
#define ESTADO_PWM_APAGADO 1
#define ESTADO_PWM10 2
#define ESTADO_PWM25 3
#define ESTADO_PWM50 4
#define ESTADO_MAXIMO_PWM 5

#define TEMP_MOTOR_SINCAMBIO	0 //INICIAL
#define TEMP_MOTOR_MUYFRIO	1 //menor o igual a 250
#define TEMP_MOTOR_FRIO		2 //mayor a 250 y menor o igual a 400
#define TEMP_MOTOR_AMB		3 //mayor a 400

#define TEMP_PWM_MUYFRIO	1
#define TEMP_PWM_FRIO	 	2
#define TEMP_PWM_FRESCO		3
#define TEMP_PWM_TIBIO		4
#define TEMP_PWM_SINCAMBIO 	5

#define PUERTA_SINCAMBIO 	0
#define PUERTA_ABIERTA		1
#define PUERTA_CERRADA		2

#define PORT0			0
#define PORT1			1
#define PORT2			2

#define PORTBOTON		PORT2
#define PINBOTON		10 //P2.10 (boton SW2)

#define PORTPUERTA		PORT2
#define PINPUERTA		10 //P2.10 (boton SW2)


#endif /* DEFINES_H_ */
