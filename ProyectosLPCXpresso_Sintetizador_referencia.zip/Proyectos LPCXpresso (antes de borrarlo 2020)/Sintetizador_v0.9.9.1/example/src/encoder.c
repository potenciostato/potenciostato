/*
 * setup.c
 *
 *  Created on: Nov 26, 2016
 *      Author: axellucas
 */

#include <board.h>
#include <FreeRTOS.h>
#include <task.h>
#include <chip.h>
#include <semphr.h>
#include <queue.h>

#include <defines.h>

static void prvSetupEncoder(void)
{
    //esto es de prueba aca iria cualquier cosa, es asi como deberia escribirse
}
